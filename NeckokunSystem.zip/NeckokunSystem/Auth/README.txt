::: 注意事項 :::
1 - venv環境で動いています。
2 - authフォルダが認証です。(dashboardフォルダがadmin dashboard)
3 - かなり繊細なためすぐエラーを起こします。(改造してから運用すること推奨)
4 - nginxでproxyすること前提です。