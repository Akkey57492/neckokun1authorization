import datetime as dt
import asyncio
import nextcord as discord
import jaconv
import json

client = discord.Client()

@client.event
async def on_ready():
	print(f"{client.user}としてログインしました!")

@client.event
async def on_message(message):
	"""
	if message.author.bot:
		if message.author.id != 302050872383242240 and message.author.id != 761562078095867916:
			return
		while True:
			print("Looped")
			channel = client.get_channel(int(message.channel.id))
			msg = await channel.fetch_message(int(message.id))
			try:
				if "をアップしたよ!" in msg.embeds[0].fields[0].name:
					print("Dissokued")
					await channel.send("dissoku upを検知しました。\n1時間後に自動通知します。")
					await asyncio.sleep(3600)
					await channel.send("前回のdissoku upから1時間経過しました。\n<@&873158106354434048>")
					break
			except IndexError:
				pass
			try:
				if "表示順をアップしたよ" in msg.embeds[0].description:
					print("Bumped")
					await channel.send("bumpを検知しました。\n2時間後に自動通知します。")
					await asyncio.sleep(7200)
					await channel.send("前回のbumpから2時間経過しました。\n<@&873158106354434048>")
					break
			except IndexError:
				pass
			try:
				if "このサーバーを上げられるようになるまで" in msg.embeds[0].description:
					await channel.send("Bumpの間隔が早すぎます。\nBumpは2時間間隔でのみできます。")
					break
			except IndexError:
				pass
			try:
				if "間隔をあけてください" in msg.embeds[0].fields[0].name:
					await channel.send("Dissokuの間隔が早すぎます。\nDissokuは1時間間隔でのみできます。")
					break
			except IndexError:
				pass
	"""
	if message.author.bot:
		return
	roles_list = []
	for role in message.author.roles:
		roles_list.append(role.id)
	if 893806416253579298 in roles_list or 893806416253579297 in roles_list or 893806416253579296 in roles_list or 893806416224202763 in roles_list:
		pass
	else:
		with open("settings.json", "r") as file:
			settings = json.load(file)
		sas_save = settings["sas"]
		message_len = len(message.content)
		if message_len >= int(sas_save):
			await message.delete()
			return
		else:
			pass
	with open("words.json", "r") as f:
		words_json = json.load(f)
	with open("response.json", "r") as f:
		res_json = json.load(f)
	respond = False
	for word in words_json["words"]:
		if respond == True:
			break
		if word in message.content:
			for res in res_json:
				if res == word:
					today = dt.datetime.today()
					today_jp = f"{today.month}月{today.day}日"
					rtime = dt.datetime.now().time()
					rtime_jp = f"{rtime.hour}時{rtime.minute}分{rtime.second}秒"
					word_send_y = res_json[str(res)]
					word_send_a = word_send_y.replace("[date]", str(today_jp))
					word_send_b = word_send_a.replace("[name]", str(message.author))
					word_send_c = word_send_b.replace("[mention]", f"<@{message.author.id}>")
					word_send_d = word_send_c.replace("[id]", str(message.author.id))
					word_send_e = word_send_d.replace("[time]", str(rtime_jp))
					await message.channel.send(str(word_send_e))
					respond = True
					break
				else:
					pass
		else:
			pass
	respond = False
	with open("rwords.json", "r") as f:
		words_json = json.load(f)
	with open("rresponse.json", "r") as f:
		res_json = json.load(f)
	for word in words_json["words"]:
		if word in message.content:
			for res in res_json:
				if res == word:
					emoji = res_json[str(res)]
					try:
						await message.add_reaction(emoji)
					except:
						await message.channel.send("エラーが発生しました。\n存在しない絵文字などを登録しませんでしたか?\n一度ワードを再登録して正しい絵文字を登録してください。")
					return
				else:
					pass
			return
		else:
			pass
	with open("ng.json", "r") as f:
		ng_words = json.load(f)
	msg = message.content
	path1 = msg.replace(" ", "")
	path2 = path1.replace("*", "")
	path3 = path2.replace("`", "")
	path4 = path3.replace("_", "")
	path5 = path4.replace("~", "")
	path6 = path5.replace("|", "")
	path7 = path6.replace("　", "")
	result = path7
	for w in ng_words["words"]:
		if w in result:
			print("ng detected")
			await message.delete()
			warn_message = await message.channel.send(f"NGwordが含まれています")
			await asyncio.sleep(5)
			await warn_message.delete()
			return
		else:
			pass
	for w in ng_words["words"]:
		hiragana = jaconv.hira2hkata(w)
		if hiragana in result:
			print("ng detected")
			await message.delete()
			warn_message = await message.channel.send(f"NGwordが含まれています")
			await asyncio.sleep(5)
			await warn_message.delete()
			return
		else:
			pass
	for w in ng_words["words"]:
		katakana = jaconv.hira2kata(w)
		if katakana in result:
			print("ng detected")
			await message.delete()
			warn_message = await message.channel.send(f"NGwordが含まれています")
			await asyncio.sleep(5)
			await warn_message.delete()
			return
		else:
			pass
	return

client.run("ODk1MjUxMTk3NjQ3MjgyMTk3.YV11pg.YefKNhMNsMf1d7Fy17GE96hi-54")