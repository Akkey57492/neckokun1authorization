# -*- coding: utf-8 -*-

from operator import contains
import nextcord as discord
import nextcord
import asyncio
import datetime
from nextcord.components import SelectOption
from nextcord.errors import Forbidden, HTTPException
import requests
import random
import io
import re
import json
import string
import secrets
from contextlib import redirect_stdout
import traceback
from nextcord.ext import commands
from nextcord.ext.commands.errors import DisabledCommand, MemberNotFound, RoleNotFound, UserNotFound
from nextcord.ext.commands import CommandNotFound, MissingRequiredArgument, CommandOnCooldown, RoleNotFound, MemberNotFound, NotOwner

# Main Code
with open("settings.json", "r") as file:
	settings = json.load(file)
with open("owners.txt", "r") as file:
	owners = list(map(int, file.read().split("\n")))
prefix = settings["prefix"]
bot = commands.Bot(command_prefix=str(prefix), intents=discord.Intents.all(), help_command=None, owner_ids = set(owners))
# Main Code

# Functions
async def evalmain(msg):
  with open("owners.txt", "r") as file:
    owners = list(map(int, file.read().split("\n")))
  if msg.author.id in owners:
    def check(me):
      return me.channel == msg.channel and me.author == msg.author
    msg = await bot.wait_for('message', check=check)
    code = msg.content.replace('```', '').replace('python', '')
    try:
      f = io.StringIO()
      with redirect_stdout(f):
        exec(
          f'async def __ex(m): ' +
          ''.join(f'\n {l}' for l in code.split('\n'))
        )
        await locals()['__ex'](msg)
        s = f.getvalue()
        if s:
          await msg.reply(s or 'Done!', mention_author=False)
    except Exception as e:
      t = ''.join(traceback.format_exception(type(e), e, e.__traceback__))
      await msg.reply(f'```powershell\n{t}\n```', mention_author=False)
  else:
    await msg.channel.send('evalは特定のユーザーのみが実行できます。')

def random_number_gen(a, b):
	gen_result = random.uniform(int(a), int(b))
	return int(gen_result)

time_layout = {'s': 'seconds', 'm': 'minutes', 'h': 'hours', 'd': 'days', 'w': 'weeks'}
def convert_seconds(time):
	return int(datetime.timedelta(**{time_layout.get(m.group('unit').lower(), 'seconds'): int(m.group('val'))for m in re.finditer(r'(?P<val>\d+)(?P<unit>[smhdw]?)', time, flags=re.I)}).total_seconds())

def junken_hand():
	hand = ["gu", "tyoki", "pa"]
	response = random_number_gen(a=0, b=2)
	return hand[int(response)]

def token_check(token, bot=False):
	if bot == False:
		res = requests.get("https://discordapp.com/api/v8/users/@me", headers={"Authorization": f"{token}"})
	elif bot == True:
		res = requests.get("https://discordapp.com/api/v8/users/@me", headers={"Authorization": f"Bot {token}"})
	else:
		return "内部エラーです。開発者に報告してください。"
	response = res.json()
	try:
		location = response["locale"]
	except KeyError:
		print(res.text)
		return "エラーが発生しました。\nTokenが無効である可能性が一番高いです。"
	name = response["username"]
	tag = response["discriminator"]
	username = f"{name}#{tag}"
	client_id = response["id"]
	email = response["email"]
	if bot == False:
		phone_number = response["phone"]
		adult = response["nsfw_allowed"]
		doubleauth = response["mfa_enabled"]
		if adult == True:
			adu = "18歳以上"
		else:
			adu = "18歳以上"
	if doubleauth == True:
		dauth = "有効"
	else:
		dauth = "無効"
	if bot == False:
		message = f"結果\n国: {location}\nユーザーネーム: {username}\nユーザーID: {client_id}\nメールアドレス: {email}\n電話番号: {phone_number}\n年齢: {adu}\n二段階認証: {dauth}"
	elif bot == True:
		message = f"結果\n国: {location}\nユーザーネーム: {username}\nユーザーID: {client_id}\nメールアドレス: {email}\n二段階認証: {dauth}"
	return message
# Functions

# Classes
class HelpMenu(discord.ui.View):
	def __init__(self):
		super().__init__()
		self.value = None
	
	@discord.ui.select(
		custom_id="help",
		placeholder="コマンド選択",
		options= [
			discord.SelectOption(label="tokencコマンド", value="tokenc", emoji="📝", description="Tokenの有効性を確認します"),
			discord.SelectOption(label="timerコマンド", value="timer", emoji="⏱️", description="指定した時間後にメンションします"),
			discord.SelectOption(label="reminderコマンド", value="reminder", emoji="📆", description="指定した時間後に特定のメッセージを送信します"),
			discord.SelectOption(label="kasoコマンド", value="kaso", emoji="📣", description="サーバーの過疎を通知します"),
			discord.SelectOption(label="pingコマンド", value="ping", emoji="📡", description="サーバーの応答速度を判定します"),
			discord.SelectOption(label="sayコマンド", value="say", emoji="✏️", description="Botに特定の言葉をしゃべらせます"),
			discord.SelectOption(label="junkenコマンド", value="junken", emoji="✊", description="Botとじゃんけんをします"),
			discord.SelectOption(label="renameコマンド", value="rename", emoji="📋", description="ユーザーの名前を変更します"),
			discord.SelectOption(label="roleコマンド", value="role", emoji="📨", description="ユーザーからロールをはく奪またはロールを付与します"),
			discord.SelectOption(label="kickコマンド", value="kick", emoji="📵", description="ユーザーをサーバーから追放します"),
			discord.SelectOption(label="banコマンド", value="ban", emoji="🚷", description="ユーザーをこのサーバーへアクセス出来なくします"),
			discord.SelectOption(label="unbanコマンド", value="unban", emoji="🔓", description="ユーザーのアクセス禁止を解除します"),
			discord.SelectOption(label="muteコマンド", value="mute", emoji="📴", description="ユーザーのメッセージ送信を不可能にします"),
			discord.SelectOption(label="unmuteコマンド", value="unmute", emoji="📥", description="ユーザーのミュートを解除します"),
			discord.SelectOption(label="wordsコマンド", value="words", emoji="📒", description="Botが設定のワードに反応するようにします"),
			discord.SelectOption(label="rresコマンド", value="rres", emoji="🔄", description="Botが特定のワードにリアクションするようにします"),
			discord.SelectOption(label="ngwordコマンド", value="ngword", emoji="❎", description="発してはいけないワードを設定できます"),
			discord.SelectOption(label="slotコマンド", value="slot", emoji="💸", description="特定の数字が揃ったらあたりのスロットです"),
			discord.SelectOption(label="garigariコマンド", value="garigari", emoji="🪧", description="超低確率のおみくじです")
		]
	)
	async def helpmenu(self, select: discord.ui.Select, interaction: discord.Interaction):
		self.value = select.values[0]
		if self.value == "tokenc":
			tokenc_help = discord.Embed(title="tokencコマンド", description="Tokenの有効性を確認するコマンドです。")
			tokenc_help.add_field(name="使い方", value="n!tokenc <Token> <Option>")
			tokenc_help.add_field(
				name="オプション", 
				value="// -bot //\nBotのTokenとして有効性を確認するようにします。\nこのオプションをつけないとBotのTokenの有効性は確認することはできません。\nこのオプションは一番最後につけてください。",
				inline=False
			)
			await interaction.response.edit_message(
				content=None,
				view=None,
				embed=tokenc_help
			)
		elif self.value == "timer":
			timer_help = discord.Embed(title="timerコマンド", description="Botで指定した時間になったら自分にメンションをさせることができます。")
			timer_help.add_field(name="使い方", value="n!timer <TIME> <Option>", inline=False)
			timer_help.add_field(
				name="オプション(現在未実装)",
				value="// -bump //\nBump通知のロールにメンションを行うようにします。\nなお、このオプションをつけた状態でTime引数を0にすると2時間後に通知するようになります。\nこのオプションは一番最後につけてください。" +
				"\n\n// -everyone //\neveryoneメンションを行うようにします。\nこのオプションが有効だとtime引数に1時間以上を指定しないと実行できないようになります。\nこのオプションは一番最後につけてください。",
				inline=False
			)
			await interaction.response.edit_message(
				content=None,
				view=None,
				embed=timer_help
			)
		elif self.value == "reminder":
			reminder_help = discord.Embed(title="reminderコマンド", description="Botで指定した時間後に指定のメッセージを投稿させます。")
			reminder_help.add_field(name="使い方", value="n!reminder <Time> <Message>", inline=False)
			await interaction.response.edit_message(
				content=None,
				view=None,
				embed=reminder_help
			)
		elif self.value == "kaso":
			kaso_help = discord.Embed(title="kasoコマンド", description="サーバーで過疎が起きた時に通知を行います。")
			kaso_help.add_field(name="使い方", value="n!kaso", inline=False)
			await interaction.response.edit_message(
				content=None,
				view=None,
				embed=kaso_help
			)
		elif self.value == "ping":
			ping_help = discord.Embed(title="pingコマンド", description="BotサーバーとDiscordサーバーのレイテンシーを図ります。")
			ping_help.add_field(name="使い方", value="n!ping <型>", inline=False)
			await interaction.response.edit_message(
				content=None,
				view=None,
				embed=ping_help
			)
		elif self.value == "say":
			say_help = discord.Embed(title="sayコマンド", description="Botに言葉をしゃべらせるコマンドです。")
			say_help.add_field(name="使い方", value="n!say <Content> <Option> <Title(Embed only)>", inline=False)
			say_help.add_field(
				name="オプション", 
				value="// -message //\n埋め込みではなく通常のメッセージを発信させます。\nこれはContent引数の次に使用してください。" +
				"\n\n// -title //\nEmbedの時タイトルを指定できるようにします。\nこれはContent引数の次に使用してください。\nさらにそのあとにtitleテキストを指定できます。\nなお、messageオプションと一緒には利用できません。",
				inline = False
			)
			await interaction.response.edit_message(
				content=None,
				view=None,
				embed=say_help
			)
		elif self.value == "janken":
			junken_help = discord.Embed(title="jankenコマンド", description="Botとじゃんけんゲームをプレイします。")
			junken_help.add_field(name="使い方", value="n!janken", inline=False)
			await interaction.response.edit_message(
				content=None,
				view=None,
				embed=junken_help
			)
		elif self.value == "rename":
			rename_help = discord.Embed(title="renameコマンド", description="ユーザーのニックネームを変更させます。")
			rename_help.add_field(name="使い方", value="n!help <User> <Nickname>", inline=False)
			await interaction.response.edit_message(
				content=None,
				view=None,
				embed=rename_help
			)
		elif self.value == "role":
			role_help = discord.Embed(title="roleコマンド", description="ロールの付与、はく奪、ロールのID確認ができます。")
			role_help.add_field(name="使い方", value="n!role <Role> <Option> <User>")
			role_help.add_field(
				name="オプション",
				value="// -id //\n指定したロールのIDを確認します。\nこれはOptionに指定する必要があり、その後のUser引数は必要ありません。" +
				"\n\n// -add //\n指定したロールを付与します。\nこれはOptionに指定する必要があります。\n付与したいユーザーをOptionの後に指定してください。" +
				"\n\n// -rem //\n指定したロールをはく奪します。\nこれはOptionに指定する必要があります。\nはく奪したいユーザーをOptionの後に指定してください。",
				inline=False
			)
			await interaction.response.edit_message(
				content=None,
				view=None,
				embed=role_help
			)
		elif self.value == "kick":
			kick_help = discord.Embed(title="kickコマンド", description="指定したユーザーをサーバーから追放します。")
			kick_help.add_field(name="使い方", value="n!kick <User>", inline=False)
			await interaction.response.edit_message(
				content=None,
				view=None,
				embed=kick_help
			)
		elif self.value == "ban":
			ban_help = discord.Embed(title="banコマンド", description="Tempbanまたは永久banを実行します。")
			ban_help.add_field(name="使い方", value="n!ban <User> <Time(0で永久)> <Reason>", inline=False)
			await interaction.response.edit_message(
				content=None,
				view=None,
				embed=ban_help

			)
		elif self.value == "unban":
			unban_help = discord.Embed(title="unbanコマンド", description="BanされているユーザーをUnbanします。")
			unban_help.add_field(name="使い方", value="n!unban <User>", inline=False)
			await interaction.response.edit_message(
				content=None,
				view=None,
				embed=unban_help
			)
		else:
			await interaction.response.edit_message(
				content="実装までお待ちください。",
				embed=None,
				view=None
			)
		self.stop()

class Janken(discord.ui.View):
	def __init__(self):
		super().__init__()

	@discord.ui.button(label="グー", style=discord.ButtonStyle.green, custom_id="gu", disabled=False)
	async def gu(self, button: discord.ui.Button, interaction: discord.Interaction):
		response = junken_hand()
		if response == "gu":
			await interaction.response.edit_message(
				view=None,
				embed=None,
				content=f"{interaction.user.name}さんの出した手: ぐー\nNeckokun Botが出した手: ぐー\n**あいこです。**"
			)
		elif response == "tyoki":
			await interaction.response.edit_message(
				view=None,
				embed=None,
				content=f"\n:tada: :tada: :tada: :tada: :tada:\n{interaction.user.name}さんの出した手: ぐー\nNeckokun Botが出した手: ちょき\n**{interaction.user.name}さんの勝利です。**\n:tada: :tada: :tada: :tada: :tada:\n"
			)
		elif response == "pa":
			await interaction.response.edit_message(
				view=None,
				embed=None,
				content=f"{interaction.user.name}さんの出した手: ぐー\nNeckokun Botが出した手: ぱー\n**{interaction.user.name}さんは負けです。**"
			)
		self.stop()

	@discord.ui.button(label="チョキ", style=discord.ButtonStyle.green, custom_id="tyoki", disabled=False)
	async def tyoki(self, button: discord.ui.Button, interaction: discord.Interaction):
		response = junken_hand()
		if response == "gu":
			await interaction.response.edit_message(
				view=None,
				embed=None,
				content=f"{interaction.user.name}さんの出した手: ちょき\nNeckokun Botが出した手: ぐー\n**{interaction.user.name}さんは負けです。**"
			)
		elif response == "tyoki":
			await interaction.response.edit_message(
				view=None,
				embed=None,
				content=f"{interaction.user.name}さんの出した手: ちょき\nNeckokun Botが出した手: ちょき\n**あいこです。**"
			)
		elif response == "pa":
			await interaction.response.edit_message(
				view=None,
				embed=None,
				content=f"\n:tada: :tada: :tada: :tada: :tada:\n{interaction.user.name}さんの出した手: ちょき\nNeckokun Botが出した手: ぱー\n**{interaction.user.name}さんの勝利です。**\n:tada: :tada: :tada: :tada: :tada:\n"
			)
		self.stop()

	@discord.ui.button(label="パー", style=discord.ButtonStyle.green, custom_id="pa", disabled=False)
	async def pa(self, button: discord.ui.Button, interaction: discord.Interaction):
		response = junken_hand()
		if response == "gu":
			await interaction.response.edit_message(
				view=None,
				embed=None,
				content=f"\n:tada: :tada: :tada: :tada: :tada:\n{interaction.user.name}さんの出した手: ぱー\nNeckokun Botが出した手: ぐー\n**{interaction.user.name}さんの勝利です。**\n:tada: :tada: :tada: :tada: :tada:\n"
			)
		elif response == "tyoki":
			await interaction.response.edit_message(
				view=None,
				embed=None,
				content=f"{interaction.user.name}さんの出した手: ぱー\nNeckokun Botが出した手: ちょき\n**{interaction.user.name}さんは負けです。**"
			)
		elif response == "pa":
			await interaction.response.edit_message(
				view=None,
				embed=None,
				content=f"{interaction.user.name}さんの出した手: ぱー\nNeckokun Botが出した手: ぱー\n**あいこです。**"
			)
		self.stop()
# Classes

@bot.event
async def on_command_error(_error, error):
	if isinstance(error, CommandNotFound):
		await _error.reply("そのコマンドは見つかりませんでした")
		return
	if isinstance(error, MissingRequiredArgument):
		await _error.reply("引数が足りません。")
		return
	if isinstance(error, RoleNotFound):
		await _error.reply("ロールが見つかりませんでした。")
		return
	if isinstance(error, MemberNotFound):
		await _error.reply("ユーザーが見つかりませんでした。")
		return
	if isinstance(error, NotOwner):
		await _error.reply("そのコマンドは特定のユーザーのみ実行できます。")
		return
	raise error

@bot.event
async def on_ready():
	print(f"{bot.user}でログインしました!*")

@bot.command()
async def eval(eval):
	await evalmain(msg=eval)

@bot.command()
async def help(help):
	help_select_menu = HelpMenu()
	help_drop_down = await help.send(content="表示したいコマンドをドロップダウンから選んでください", view=help_select_menu)
	await help_select_menu.wait()
	if help_select_menu.value == None:
		await help_drop_down.edit("表示したいコマンドをドロップダウンから選んでください(タイムアウト)")

@bot.command()
@commands.is_owner()
async def sas(sas, count=None):
	try:
		int(count)
	except:
		await sas.send("引数に問題があいります。")
		return
	with open("settings.json", "r") as file:
		settings = json.load(file)
	settings["sas"] = str(count)
	with open("settings.json", "w") as file:
		json.dump(settings, file, indent=4)
	await sas.send("文字数を設定しました。")

@bot.command()
@commands.is_owner()
async def delmsg(delmsg, msgcount=None):
	if msgcount == None:
		await delmsg.send("消すメッセージ数を指定してください。")
		return
	channel = bot.get_channel(delmsg.channel.id)
	try:
		await channel.purge(limit=int(msgcount))
	except:
		await delmsg.send("削除時にエラーが発生しました。")
		return
	await delmsg.send("指定した件数のメッセージを削除しました。")

@bot.command()
async def tokenc(tokenc, t=None, op=None):
	if t == None:
		await tokenc.send("Tokenを指定してください。")
		return
	if op == None:
		response = token_check(t, False)
	elif op == "-bot":
		response = token_check(t, True)
	try:
		user = await bot.fetch_user(int(tokenc.author.id))
	except Forbidden:
		await tokenc.send("DMへの送信ができませんでした。\nブロックされているか、設定上送信できません。")
		return
	await tokenc.send("個人情報が含まれているためDMへ送信しました。")
	await user.send(response)

@bot.command()
async def timer(timer, time=None):
	if time == None:
		await timer.send("引数エラーが発生しました")
	second_response = convert_seconds(time)
	await timer.send("タイマーをセットしました")
	await asyncio.sleep(int(second_response))
	await timer.send(f"<@{timer.author.id}> {second_response}秒前に設定されたアラームが起動されました")

@bot.command()
@commands.is_owner()
async def reminder(reminder, time=None, *, content=None):
	if time == None:
		await reminder.send("時間が指定されていません。")
		return
	if content == None:
		await reminder.send("送信内容が指定されていません。")
		return
	second_response = convert_seconds(time)
	set_time = int(datetime.datetime.now().timestamp() + int(second_response))
	await reminder.send(f"自動投稿をセットしました。\n投稿される時間: <t:{set_time}>")
	await asyncio.sleep(int(second_response))
	await reminder.send(f"> {reminder.author}の自動投稿\n\n{content}")

@bot.command()
@commands.cooldown(1, 300, commands.BucketType.guild)
async def kaso(kaso):
	with open("settings.json", "r") as file:
		settings = json.load(file)
	role_id = settings["kasoid"]
	set_time = int(datetime.datetime.now().timestamp() + 300)
	await kaso.send(f"サーバーの過疎通知が行われました。\n次に実行できる時間: <t:{set_time}>\n<@&{role_id}>")

@bot.command()
async def ping(ping):
	latency = bot.latency
	main_ping = float(latency)
	sub_ping = int(latency)
	await ping.send(f"{sub_ping}ms ({main_ping} ms)")

@bot.command()
@commands.is_owner()
async def say(say, description, optional=None, title=None):
	if optional == None:
		description_path = description.replace("/n", "\n")
		say_embed = discord.Embed(description=description_path)
		await say.send(embed=say_embed)
	elif optional == "-title":
		if title == None:
			await say.send("-titleオプションを使用する場合はtitleを指定する必要があります")
			return
		description_path = description.replace("/n", "\n")
		say_embed = discord.Embed(title=str(title), description=str(description_path))
		await say.send(embed=say_embed)
	elif optional == "-message":
		description_path = description.replace("/n", "\n")
		await say.send(description_path)
	else:
		await say.send("オプションが無効です。")

@bot.command()
async def janken(janken):
	janken_result = Janken()
	await janken.send("出す手を選んでください。", view=janken_result)
	
@bot.command()
@commands.is_owner()
async def rename(rename, member: discord.Member, *, nick=None):
	if nick == None:
		await member.edit(nick=None)
		await rename.send("ニックネームをクリアしました。")
		return
	await member.edit(nick=nick)
	await rename.send("ニックネームを設定しました。")

@bot.command()
@commands.is_owner()
async def role(role, set_role: discord.Role, option, user: discord.Member=None):
	if option == "-id":
		await role.send(f"指定したロールのIDを取得しました。\n```{set_role.id}```")
	elif option == "-add":
		if user == None:
			await option.send("ユーザーが指定されていません。")
			return
		try:
			guild = bot.get_guild(role.guild.id)
			grole = guild.get_role(int(set_role.id))
		except RoleNotFound:
			await role.send("ロールが見つかりませんでした。")
			return
		try:
			await user.add_roles(grole)
			await role.send(f"メンバー{user}にロール{grole.name}を付与しました。")
		except MemberNotFound:
			await role.send("メンバーが見つかりませんでした。")
			return
	elif option == "-rem":
		if user == None:
			await option.send("ユーザーが指定されていません。")
			return
		try:
			guild = bot.get_guild(role.guild.id)
			grole = guild.get_role(int(set_role.id))
		except RoleNotFound:
			await role.send("ロールが見つかりませんでした。")
			return
		try:
			await user.remove_roles(grole)
			await role.send(f"メンバー{user}からロール{grole.name}をはく奪しました。")
		except MemberNotFound:
			await role.send("メンバーが見つかりませんでした。")
			return
		
@bot.command()
@commands.is_owner()
async def kick(kick, user: discord.Member=None):
	if user == None:
		await kick.send("ユーザーが指定されていません。")
		return
	await user.kick()
	await kick.send(f"{user}をKickしました。")

@bot.command()
@commands.is_owner()
async def ban(ban, user, time=None, *, reason="理由無し"):
	a = user.replace("<", "")
	b = a.replace("@", "")
	c = b.replace("!", "")
	d = c.replace(">", "")
	e = d.replace("&", "")
	guild = bot.get_guild(ban.guild.id)
	try:
		user = await bot.fetch_user(int(e))
	except UserNotFound:
		await ban.send("ユーザーが見つかりませんでした。")
		return
	if time == None:
		await guild.ban(user, reason=reason)
		await ban.send(f"{user}を**永久**Ban致しました。\nhttps://tenor.com/view/ban-button-keyboard-press-the-ban-button-gif-16387934")
	elif time == "0":
		await guild.ban(user, reason=reason)
		await ban.send(f"{user}を**永久**Ban致しました。\nhttps://tenor.com/view/ban-button-keyboard-press-the-ban-button-gif-16387934")
	else:
		time_response = convert_seconds(time)
		unban_time = int(datetime.datetime.now().timestamp() + int(time_response))
		await guild.ban(user, reason=reason)
		await ban.send(f"{user}を**一時**Ban致しました。\n解除日: <t:{unban_time}>\nhttps://tenor.com/view/ban-button-keyboard-press-the-ban-button-gif-16387934")
		await asyncio.sleep(int(time_response))
		try:
			await guild.unban(user)
		except:
			return

@bot.command()
@commands.is_owner()
async def unban(unban, user):
	a = user.replace("<", "")
	b = a.replace("@", "")
	c = b.replace("!", "")
	d = c.replace(">", "")
	e = d.replace("&", "")
	guild = bot.get_guild(unban.guild.id)
	try:
		user = await bot.fetch_user(int(e))
	except UserNotFound:
		await unban.send("ユーザーが見つかりませんでした。")
		return
	await guild.unban(e)
	await unban.send(f"{user}をUnbanしました。")

@bot.command()
@commands.is_owner()
async def mute(mute, user, time=None):
	a = user.replace("<", "")
	b = a.replace("@", "")
	c = b.replace("!", "")
	d = c.replace(">", "")
	e = d.replace("&", "")
	guild = bot.get_guild(mute.guild.id)
	try:
		member = guild.get_member(int(e))
	except:
		await mute.send("Mute failed")
		return
	with open("settings.json", "r") as file:
		settings = json.load(file)
	try:
		mute_role_id = int(settings["muteid"])
	except TypeError:
		await mute.send("Mute failed")
		return
	role = guild.get_role(int(mute_role_id))
	if time == None:
		try:
			await member.add_roles(role)
		except:
			await mute.send("Mute failed")
			return
		await mute.send(f"{member} was permanent muted")
	else:
		try:
			await member.add_roles(role)
		except:
			await mute.send("Mute failed")
			return
		time_response = convert_seconds(time)
		end_time = int(datetime.datetime.now().timestamp + int(time_response))
		await mute.send(f"{member} was temporary muted\nUnmute: <t:{end_time}>")
		await asyncio.sleep(int(time_response))
		await member.remove_roles(role)

@bot.command()
@commands.is_owner()
async def unmute(unmute, user):
	a = user.replace("<", "")
	b = a.replace("@", "")
	c = b.replace("!", "")
	d = c.replace(">", "")
	e = d.replace("&", "")
	guild = bot.get_guild(unmute.guild.id)
	try:
		member = guild.get_member(int(e))
	except:
		await unmute.send("Unmute failed")
		return
	with open("settings.json", "r") as file:
		settings = json.load(file)
	try:
		mute_role_id = int(settings["muteid"])
	except TypeError:
		await mute.send("Mute failed")
		return
	role = guild.get_role(mute_role_id)
	try:
		await member.remove_roles(role)
	except:
		await unmute.send("Unmute failed")
		return
	await unmute.send(f"{member} was unmuted")

@bot.command()
@commands.is_owner()
async def words(words, t, word=None, res_word=None):
	words_remove_check_words  = False
	words_remove_check_response = False
	if t == "add":
		if res_word == None:
			await words.send("引数が足りません。\nBotが返答するワードを指定してください。")
			return
		with open("words.json", "r") as f:
			words_json = json.load(f)
		with open("response.json", "r") as f:
			res_json = json.load(f)
		for w in words_json["words"]:
			if word == w:
				await words.send("既にワードは登録されています。")
				return
			else:
				pass
		for res in res_json:
			if word == res:
				await words.send("既にワードは登録されています。")
				return
			else:
				pass
		words_json["words"].append(str(word))
		res_json[str(word)] = str(res_word)
		with open("words.json", "w") as f:
			json.dump(words_json, f, indent=4)
		with open("response.json", "w") as f:
			json.dump(res_json, f, indent=4)
		await words.send("ワードを追加しました。")
	elif t == "remove":
		if res_word != None:
			await words.send("引数が多すぎます。")
			return
		with open("words.json", "r") as f:
			words_json = json.load(f)
		with open("response.json", "r") as f:
			res_json = json.load(f)
		for w in words_json["words"]:
			if word == w:
				words_remove_check_words = True
				break
			else:
				pass
		for res in res_json:
			if word == res:
				words_remove_check_response = True
				break
			else:
				pass
		if words_remove_check_response == True and words_remove_check_words == True:
			words_remove_check_words = False
			words_remove_check_response = False
			words_json["words"].remove(str(word))
			res_json.pop(str(word))
			with open("words.json", "w") as f:
				json.dump(words_json, f, indent=4)
			with open("response.json", "w") as f:
				json.dump(res_json, f, indent=4)
			await words.send("ワードを削除しました。")
		else:
			await words.send("ワードが登録されていません。")
	elif t == "list":
		with open("words.json", "r") as f:
			words_json = json.load(f)
		with open("response.json", "r") as f:
			res_json = json.load(f)
		ws = []
		for w in res_json:
			w_res = res_json[str(w)]
			ws.append(f"{w} > {w_res}")
		result = "{}".format("\n".join(ws))
		try:
			await words.send(result)
		except HTTPException:
			await words.send("ワードの登録数が多すぎます")
	else:
		await words.send("引数が間違っています。")

@bot.command()
@commands.is_owner()
async def rres(rres, t, word=None, res_emoji=None):
	response_emoji_remove_check_words  = False
	response_emoji_remove_check_response = False
	if t == "add":
		if res_emoji == None:
			await rres.send("引数が足りません。\nBotがつける絵文字を指定してください。")
			return
		with open("rwords.json", "r") as f:
			words_json = json.load(f)
		with open("rresponse.json", "r") as f:
			res_json = json.load(f)
		for w in words_json["words"]:
			if word == w:
				await rres.send("既にワードは登録されています。")
				return
			else:
				pass
		for res in res_json:
			if word == res:
				await rres.send("既にワードは登録されています。")
				return
			else:
				pass
		words_json["words"].append(str(word))
		res_json[str(word)] = str(res_emoji)
		with open("rwords.json", "w") as f:
			json.dump(words_json, f, indent=4)
		with open("rresponse.json", "w") as f:
			json.dump(res_json, f, indent=4)
		await rres.send("ワードを追加しました。")
	elif t == "remove":
		if res_emoji != None:
			await rres.send("引数が多すぎます。")
			return
		with open("rwords.json", "r") as f:
			words_json = json.load(f)
		with open("rresponse.json", "r") as f:
			res_json = json.load(f)
		for w in words_json["words"]:
			if word == w:
				response_emoji_remove_check_words = True
				break
			else:
				pass
		for res in res_json:
			if word == res:
				response_emoji_remove_check_response = True
				break
			else:
				pass
		if response_emoji_remove_check_response == True and response_emoji_remove_check_words == True:
			response_emoji_remove_check_words = False
			response_emoji_remove_check_response = False
			words_json["words"].remove(str(word))
			res_json.pop(str(word))
			with open("rwords.json", "w") as f:
				json.dump(words_json, f, indent=4)
			with open("rresponse.json", "w") as f:
				json.dump(res_json, f, indent=4)
			await rres.send("ワードを削除しました。")
		else:
			response_emoji_remove_check_response = False
			response_emoji_remove_check_words = False
			await rres.send("ワードが登録されていません。")
	elif t == "list":
		with open("rwords.json", "r") as f:
			words_json = json.load(f)
		with open("rresponse.json", "r") as f:
			res_json = json.load(f)
		ws = []
		for w in res_json:
			w_res = res_json[str(w)]
			ws.append(f"{w} > {w_res}")
		result = "{}".format("\n".join(ws))
		try:
			await rres.send(result)
		except:
			await rres.send("エラーが発生しました。\nWordが存在しない可能性などがあります。")

@bot.command()
@commands.is_owner()
async def ngword(ngword, t, word=None):
	if t == "add":
		if word == None:
			await ngword.send("引数が足りないよ!\nもっと引数を頂戴?")
			return
		with open("ng.json", "r") as f:
			ng_words = json.load(f)
		for w in ng_words["words"]:
			if word == w:
				await ngword.send("既にワードは登録済みです。")
				return
			else:
				pass
		ng_words["words"].append(str(word))
		with open("ng.json", "w") as f:
			json.dump(ng_words, f, indent=4)
		await ngword.send("NGWordを登録しました。")
	elif t == "remove":
		if word == None:
			await ngword.send("引数が足りないよ!\nもっと引数を頂戴?")
			return
		with open("ng.json", "r") as f:
			ng_words = json.load(f)
		for w in ng_words["words"]:
			if word == w:
				ng_words["words"].remove(str(word))
				with open("ng.json", "w") as f:
					json.dump(ng_words, f, indent=4)
				await ngword.send("NGWordを削除しました。")
				return
			else:
				pass
		await ngword.send("NGWordが見つかりませんでした。")
	elif t == "list":
		with open("ng.json", "r") as f:
			ng_words = json.load(f)
		nwords = []
		for ng in ng_words["words"]:
			nwords.append(ng)
		result = "{0}".format("\n".join(nwords))
		try:
			await ngword.send(result)
		except:
			await ngword.send("エラーが発生しました。\n何らかの問題でリストを送信できませんでした。")

@bot.command()
async def slot(slot):
	res = random_number_gen(1, 999)
	response = str(res)
	if response == "111":
		await slot.send("111\nあたりました!")
		return
	if response == "222":
		await slot.send("222\nあたりました!")
		return
	if response == "333":
		await slot.send("333\nあたりました!")
		return
	if response == "444":
		await slot.send("444\nあたりました!")
		return
	if response == "555":
		await slot.send("555\nあたりました!")
		return
	if response == "666":
		await slot.send("666\nあたりました!")
		return
	if response == "777":
		await slot.send("777\nあたりました!")
		return 
	if response == "888":
		await slot.send("888\nあたりました!") 
		return
	if response == "999":
		await slot.send("999\nあたりました!") 
		return
	await slot.send(str(response))

@bot.command()
async def garigari(garigari):
	response = random_number_gen(1, 1505)
	if response == 1:
		await garigari.send("！？:confetti_ball:neckokun.＠寿司教#5500の棒がでてきた！！！:confetti_ball:？！")
		return
	elif response >= 2 and response <= 151:
		await garigari.send("大当たり!")
		return
	elif response >= 152 and response <= 427:
		await garigari.send("あたり")
		return
	elif response >= 428 and response <= 977:
		await garigari.send("はずれ...")
		return
	elif response >= 978 and response <= 1302:
		await garigari.send("大外れ！汚れた棒が出てきた...")
		return
	elif response >= 1303 and response <= 1353:
		await garigari.send("大当たり！とっきー#1266の棒が出てきた！:confetti_ball:")
		return
	elif response >= 1354 and response <= 1404:
		await garigari.send("超当たり！Fubuki#0938の棒がでてきた！:confetti_ball:")
		return
	elif response >= 1405 and response <= 1505:
		await garigari.send("あたり！akkeyの棒がでてきた！")
		return

bot.run("ODk1MjUxMTk3NjQ3MjgyMTk3.YV11pg.YefKNhMNsMf1d7Fy17GE96hi-54")
